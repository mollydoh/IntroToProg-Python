'''Dev: SYan
Lab_5: Create a new script that manages a "ToDo list." a tex
----------------------------------------------------------------------------'''
#1 Load data from a file called "ToDo.txt"
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"
newfile = open("ToDo.txt", "a")

strData = ""
dicRow = {}
lstTable = [] 
strSaveToFile = ()

print("\n--- multi-dimensional")

lstRow1 = ["Clean House", "low"]
lstRow2 = ["Pay Bill", "high"]
lstTable = [lstRow1, lstRow2]
print(lstTable)

#2 Display a menu of choices to the user
while(True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)

    strChoice = str(input('Which option would you like to perform? [1-4] -'))
    print()

#3 Show the current items in the table                   
    if (strChoice.strip() == '1'):
        print(lstTable)
        continue
    
#4 Add a new item to the list/Table
    elif (strChoice.strip == '2'):
        print("\n--- insert")
        lstRow3 = ["Enter the name and description: "]
        lstTable.insert(0, lstRow3)
        print("Data\n\r",lstTable)
        
        continue

#5 Remove a new item to the li st/Table
    elif (strChoice == '3'):
        print("\n--- remove")
        lstRow1.Remove["Enter the name and description: "]
        print("Data\n\r",lstTable)
        
        continue
    
#6 Save tasks to the ToDo.txt file by asking yes or no
    elif (strChoice == '4'):
        strSaveToFile = input("Would you like to save this data to a file? ('y'/'n'): ")
        if(strSaveToFile.lower() == 'y'):
            print("The following data was saved to a file:\n\r",lstTable)
        else:
            print("Data not saved!")
            
        continue
    
    elif (strChoice == '5'):
        break #and Exit the program
newfile.close
newfile = open("ToDo.txt", "r")
print(newfile.readline())

input()


        
